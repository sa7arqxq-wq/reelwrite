/*
 * ReelWrite — 7-second reels for writers
 * Copyright (c) 2026 ReelWrite. All rights reserved.
 *
 * PROPRIETARY AND CONFIDENTIAL
 * This source code is the proprietary work of ReelWrite. No part of this
 * software may be copied, reproduced, distributed, or used to create
 * derivative works without the express written permission of ReelWrite.
 * Unauthorized use, duplication, or distribution is prohibited.
 *
 * For licensing inquiries: legal@reelwrite.app
 */

"use client";

import { useEffect, useState } from "react";
import { Loader2, BookOpen, ExternalLink, Settings, PenLine, Camera, Loader2 as Spinner, Trash2, Archive, Pencil, Lock, Unlock, MessageCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { compressImage } from "@/lib/image-compress";
import { BookCover } from "./BookCover";
import { MOODS } from "@/lib/moods";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

interface ProfileReel {
  id: string;
  hook: string;
  mood: string;
  likes: number;
  views: number;
  comments: number;
  createdAt: string;
  archived?: boolean;
  book: {
    title: string;
    subtitle: string;
    coverColor: string;
    coverAccent: string;
    coverEmoji: string;
    genre: string;
    buyLink: string;
  } | null;
}

interface ProfileBook {
  id: string;
  title: string;
  subtitle: string;
  coverColor: string;
  coverAccent: string;
  coverEmoji: string;
  description: string;
  genre: string;
  buyLink: string;
  pages: number;
}

interface WriterProfile {
  id: string;
  username: string;
  displayName: string;
  bio: string;
  avatarColor: string;
  avatarEmoji: string;
  image?: string | null;
  isPrivate?: boolean;
  followers: number;
  following: number;
  reelsCount: number;
  reels: ProfileReel[];
  books: ProfileBook[];
}

interface ProfileViewProps {
  writerId: string;
  isMe: boolean;
  currentUserId?: string;
  onEditBio?: (newBio: string) => void;
  onOpenDM?: (userId: string) => void;
  onOpenReelInFeed?: (reelId: string) => void;
}

function formatCount(n: number): string {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1).replace(/\.0$/, "") + "M";
  if (n >= 1_000) return (n / 1_000).toFixed(1).replace(/\.0$/, "") + "K";
  return String(n);
}

export function ProfileView({ writerId, isMe, currentUserId, onEditBio, onOpenDM }: ProfileViewProps) {
  const [profile, setProfile] = useState<WriterProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [editingBio, setEditingBio] = useState(false);
  const [bioDraft, setBioDraft] = useState("");
  const [following, setFollowing] = useState(false);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    setLoading(true);
    fetch(`/api/writers/${writerId}`)
      .then((r) => r.json())
      .then((data) => {
        setProfile(data.writer);
        setBioDraft(data.writer?.bio || "");
      })
      .finally(() => setLoading(false));
  }, [writerId]);

  if (loading || !profile) {
    return (
      <div className="flex h-full items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-amber-400" />
      </div>
    );
  }

  async function handlePhotoUpload(file: File) {
    setUploadingPhoto(true);
    try {
      const dataUrl = await compressImage(file, 400, 0.85);
      const res = await fetch("/api/me/profile-image", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ image: dataUrl }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast({
          title: "Upload failed",
          description: data.error || "Could not update photo",
          variant: "destructive",
        });
        return;
      }
      setProfile((p) => p ? { ...p, image: data.image } : p);
      toast({ title: "Profile photo updated ✨" });
    } catch (e) {
      toast({
        title: "Upload failed",
        description: e instanceof Error ? e.message : "Could not process image",
        variant: "destructive",
      });
    } finally {
      setUploadingPhoto(false);
    }
  }

  async function handleRemovePhoto() {
    setUploadingPhoto(true);
    try {
      await fetch("/api/me/profile-image", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ image: null }),
      });
      setProfile((p) => p ? { ...p, image: null } : p);
      toast({ title: "Profile photo removed" });
    } finally {
      setUploadingPhoto(false);
    }
  }

  return (
    <div className="no-scrollbar h-full overflow-y-auto pt-20 pb-24">
      {/* Header */}
      <div className="px-4 pb-4">
        <div className="flex items-start gap-4">
          {/* Profile photo — with upload button if it's your profile */}
          <div className="relative shrink-0">
            {profile.image ? (
              <img
                src={profile.image}
                alt={profile.displayName}
                className="w-20 h-20 rounded-full object-cover ring-4 ring-white/10"
              />
            ) : (
              <span
                className="flex w-20 h-20 shrink-0 rounded-full items-center justify-center text-3xl ring-4 ring-white/10"
                style={{ background: profile.avatarColor }}
              >
                {profile.avatarEmoji}
              </span>
            )}
            {isMe && (
              <label className="absolute -bottom-1 -right-1 cursor-pointer">
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) handlePhotoUpload(file);
                  }}
                />
                <span className="flex w-8 h-8 rounded-full bg-amber-400 items-center justify-center text-black shadow-lg hover:bg-amber-300 transition-colors">
                  {uploadingPhoto ? (
                    <Spinner className="w-4 h-4 animate-spin" />
                  ) : (
                    <Camera className="w-4 h-4" />
                  )}
                </span>
              </label>
            )}
          </div>
          <div className="min-w-0 flex-1 pt-1">
            <h1 className="text-xl font-bold truncate">{profile.displayName}</h1>
            <p className="text-sm text-white/50 truncate">@{profile.username}</p>
            <div className="mt-2 flex gap-4 text-sm">
              <div>
                <span className="font-bold">{formatCount(profile.followers)}</span>{" "}
                <span className="text-white/55">followers</span>
              </div>
              <div>
                <span className="font-bold">{profile.reelsCount}</span>{" "}
                <span className="text-white/55">reels</span>
              </div>
              <div>
                <span className="font-bold">{profile.books.length}</span>{" "}
                <span className="text-white/55">books</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bio */}
        <div className="mt-4">
          {editingBio ? (
            <div className="space-y-2">
              <Textarea
                value={bioDraft}
                onChange={(e) => setBioDraft(e.target.value)}
                rows={2}
                className="bg-white/5 border-white/15 text-white text-sm focus-visible:ring-amber-400/50 resize-none"
              />
              <div className="flex gap-2">
                <Button
                  size="sm"
                  className="bg-amber-400 text-black hover:bg-amber-300"
                  onClick={() => {
                    onEditBio?.(bioDraft);
                    setEditingBio(false);
                    if (profile) setProfile({ ...profile, bio: bioDraft });
                  }}
                >
                  Save
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  className="text-white/70 hover:text-white"
                  onClick={() => setEditingBio(false)}
                >
                  Cancel
                </Button>
              </div>
            </div>
          ) : (
            <div className="flex items-start gap-2">
              <p className="text-sm text-white/85 flex-1 leading-relaxed">
                {profile.bio || "No bio yet."}
              </p>
              {isMe && (
                <button
                  onClick={() => setEditingBio(true)}
                  className="text-white/40 hover:text-amber-400 transition-colors"
                  aria-label="Edit bio"
                >
                  <PenLine className="w-4 h-4" />
                </button>
              )}
            </div>
          )}
        </div>

        {/* CTA */}
        <div className="mt-4 flex gap-2">
          {isMe ? (
            <>
              <Button
                variant="outline"
                className="border-white/20 text-white hover:bg-white/10 flex-1"
                onClick={() => setEditingBio(true)}
              >
                <Settings className="w-4 h-4 mr-2" />
                Edit profile
              </Button>
              <Button
                variant="outline"
                className={cn(
                  "border-white/20 hover:bg-white/10",
                  profile.isPrivate ? "text-amber-400" : "text-white/70"
                )}
                onClick={async () => {
                  try {
                    const res = await fetch("/api/me/privacy", {
                      method: "PATCH",
                      headers: { "Content-Type": "application/json" },
                      body: JSON.stringify({ isPrivate: !profile.isPrivate }),
                    });
                    const data = await res.json();
                    if (data.ok) {
                      setProfile((p) => p ? { ...p, isPrivate: data.isPrivate } : p);
                      toast({
                        title: data.isPrivate ? "Account is now private 🔒" : "Account is now public 🔓",
                      });
                    }
                  } catch {
                    toast({ title: "Could not update privacy", variant: "destructive" });
                  }
                }}
                title={profile.isPrivate ? "Account is private" : "Account is public"}
              >
                {profile.isPrivate ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
              </Button>
            </>
          ) : (
            <>
              <Button
                className={cn(
                  "flex-1 font-bold",
                  following
                    ? "bg-white/10 text-white hover:bg-white/15"
                    : "bg-amber-400 text-black hover:bg-amber-300"
                )}
                onClick={() => setFollowing((f) => !f)}
              >
                {following ? "Following" : "Follow"}
              </Button>
              <Button
                variant="outline"
                className="border-white/20 text-white hover:bg-white/10"
                onClick={() => onOpenDM?.(profile.id)}
              >
                <MessageCircle className="w-4 h-4" />
              </Button>
            </>
          )}
        </div>
      </div>

      {/* Reels grid */}
      {profile.reels.length > 0 && (
        <section className="px-4 mb-6">
          <div className="flex items-center gap-2 mb-2">
            <h2 className="text-sm font-bold uppercase tracking-wider text-white/55">
              🎬 My Reels
            </h2>
            <span className="text-[10px] text-white/35">({profile.reels.length})</span>
            {isMe && profile.reels.some(r => r.archived) && (
              <span className="text-[10px] text-amber-400/70 ml-auto">📦 {profile.reels.filter(r => r.archived).length} archived</span>
            )}
          </div>
          <div className="grid grid-cols-3 gap-1.5">
            {profile.reels.map((r) => {
              const mood = MOODS[(r.mood as keyof typeof MOODS) || "amber"];
              return (
                <div
                  key={r.id}
                  className={cn(
                    "relative aspect-[9/14] rounded-md overflow-hidden border border-white/10 group",
                    r.archived && "opacity-40"
                  )}
                  style={{
                    background: `linear-gradient(160deg, ${mood.from}, ${mood.to})`,
                  }}
                >
                  <div className="absolute inset-0 p-2 flex flex-col justify-between">
                    <div
                      className="text-[10px] font-serif font-bold leading-tight line-clamp-4"
                      style={{ color: mood.accent }}
                    >
                      {r.hook}
                    </div>
                    <div className="text-[8px] text-white/60 flex items-center gap-1">
                      <span>❤️ {formatCount(r.likes)}</span>
                      {r.archived && <span className="text-amber-400">📦 Archived</span>}
                    </div>
                  </div>
                  {/* Reel management buttons — only on your own profile */}
                  {isMe && (
                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-1.5">
                      <button
                        onClick={async () => {
                          const newHook = prompt("Edit your hook:", r.hook);
                          if (newHook && newHook !== r.hook) {
                            const res = await fetch(`/api/reels/${r.id}/edit`, {
                              method: "PATCH",
                              headers: { "Content-Type": "application/json" },
                              body: JSON.stringify({ hook: newHook }),
                            });
                            if (res.ok) {
                              toast({ title: "Reel edited ✏️" });
                              setProfile((p) => p ? {
                                ...p,
                                reels: p.reels.map((rr) => rr.id === r.id ? { ...rr, hook: newHook } : rr)
                              } : p);
                            }
                          }
                        }}
                        className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center text-white hover:bg-white/30"
                        title="Edit"
                      >
                        <Pencil className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={async () => {
                          const res = await fetch(`/api/reels/${r.id}/archive`, { method: "POST" });
                          if (res.ok) {
                            const data = await res.json();
                            toast({ title: data.archived ? "Reel archived 📦" : "Reel unarchived" });
                            setProfile((p) => p ? {
                              ...p,
                              reels: p.reels.map((rr) => rr.id === r.id ? { ...rr, archived: data.archived } : rr)
                            } : p);
                          }
                        }}
                        className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center text-white hover:bg-white/30"
                        title={r.archived ? "Unarchive" : "Archive"}
                      >
                        <Archive className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={async () => {
                          if (!confirm("Delete this reel permanently?")) return;
                          const res = await fetch(`/api/reels/${r.id}/delete`, { method: "DELETE" });
                          if (res.ok) {
                            toast({ title: "Reel deleted 🗑️", variant: "destructive" });
                            setProfile((p) => p ? {
                              ...p,
                              reels: p.reels.filter((rr) => rr.id !== r.id),
                              reelsCount: p.reelsCount - 1,
                            } : p);
                          }
                        }}
                        className="w-8 h-8 rounded-full bg-rose-500/30 flex items-center justify-center text-rose-400 hover:bg-rose-500/50"
                        title="Delete"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* Books */}
      {profile.books.length > 0 && (
        <section className="px-4">
          <h2 className="text-sm font-bold uppercase tracking-wider text-white/55 mb-3">
            Books
          </h2>
          <div className="space-y-3">
            {profile.books.map((b) => (
              <div
                key={b.id}
                className="flex gap-3 rounded-xl bg-white/[0.04] border border-white/10 p-3"
              >
                <BookCover
                  title={b.title}
                  subtitle={b.subtitle}
                  coverColor={b.coverColor}
                  coverAccent={b.coverAccent}
                  coverEmoji={b.coverEmoji}
                  size="sm"
                />
                <div className="min-w-0 flex-1">
                  <div className="text-[10px] uppercase tracking-wider text-white/55 font-semibold">
                    {b.genre} · {b.pages || "?"}p
                  </div>
                  <div className="text-sm font-bold truncate">{b.title}</div>
                  <p className="text-xs text-white/70 mt-1 line-clamp-2">
                    {b.description || "A new release from this author."}
                  </p>
                  {b.buyLink && (
                    <a
                      href={b.buyLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="mt-2 inline-flex items-center gap-1.5 text-xs font-bold text-amber-400 hover:text-amber-300"
                    >
                      <BookOpen className="w-3.5 h-3.5" />
                      Read this book
                      <ExternalLink className="w-3 h-3 opacity-70" />
                    </a>
                  )}
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {profile.reels.length === 0 && profile.books.length === 0 && (
        <div className="px-6 py-12 text-center">
          <div className="text-4xl mb-2">✍️</div>
          <p className="text-sm text-white/55">
            {isMe
              ? "You haven't published any reels yet. Tap Create to make your first 7-second reel."
              : "No reels yet."}
          </p>
        </div>
      )}

      {/* Saved reels — only visible on your own profile */}
      {isMe && (
        <div className="px-4 mb-2">
          <div className="h-px bg-white/10 my-4" />
        </div>
      )}
      {isMe && <SavedReelsSection />}

    </div>
  );
}

// Saved reels section — fetches and displays reels the writer has saved
function SavedReelsSection() {
  const [savedReels, setSavedReels] = useState<ProfileReel[]>([]);
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    fetch("/api/me/saved")
      .then((r) => r.json())
      .then((data) => setSavedReels(data.reels || []))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  if (loading) return null;
  if (savedReels.length === 0) return null;

  return (
    <section className="px-4 mb-6">
      <button
        onClick={() => setExpanded((e) => !e)}
        className="flex items-center justify-between w-full mb-2 bg-amber-400/10 rounded-lg px-3 py-2 border border-amber-400/20"
      >
        <h2 className="text-sm font-bold text-amber-400 flex items-center gap-2">
          🔖 Saved Reels
          <span className="text-white/40 font-normal">({savedReels.length})</span>
        </h2>
        <span className="text-xs text-amber-400/70">{expanded ? "▲ Hide" : "▼ Show"}</span>
      </button>
      {expanded && (
        <div className="grid grid-cols-3 gap-1.5">
          {savedReels.map((r) => {
            const mood = MOODS[(r.mood as keyof typeof MOODS) || "amber"];
            return (
              <div
                key={r.id}
                className="relative aspect-[9/14] rounded-md overflow-hidden border border-white/10"
                style={{ background: `linear-gradient(160deg, ${mood.from}, ${mood.to})` }}
              >
                <div className="absolute inset-0 p-2 flex flex-col justify-between">
                  <div
                    className="text-[10px] font-serif font-bold leading-tight line-clamp-4"
                    style={{ color: mood.accent }}
                  >
                    {r.hook}
                  </div>
                  <div className="text-[8px] text-white/60">
                    ❤️ {formatCount(r.likes)}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
}
